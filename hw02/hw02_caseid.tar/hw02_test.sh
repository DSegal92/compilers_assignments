make clean
make
./ansi_c < main.c
./ansi_c < Code_1_6_1.c
./ansi_c < Code_1_6_2.c
cpp Code_1_6_4.c > Code_1_6_4.cpp
./ansi_c < Code_1_6_4.cpp
