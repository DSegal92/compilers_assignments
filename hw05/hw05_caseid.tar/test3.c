baa
bab
bba
bbb
