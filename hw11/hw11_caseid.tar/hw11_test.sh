#
#	hw11_test.sh
#
make clean
make
./calc math17.calc
./calc math18.calc
#./calc math19.calc
