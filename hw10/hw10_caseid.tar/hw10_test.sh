#
#	hw10_test.sh
#
make clean
make
./calc math14.calc
./calc math15.calc
#./calc math16.calc
