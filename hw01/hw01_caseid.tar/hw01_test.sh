make clean
make
./Code_1_6_1
./Code_1_6_2
./Code_1_6_4
./Echo < Echo.c