/*******************************************************************************
*
* FILE:		Echo.c
*
* DESC:		EECS 337 Homework Assignment 1
*
* AUTHOR:	caseid
*
* DATE:		August 28, 2012
*
* EDIT HISTORY:	
*
*******************************************************************************/
#include	<stdio.h>
/*
 *	main program
 */
int	main( int argc, char *argv[])
{
	int c;
// while input character from stdin does not equal end of file (-1)
	while(( c = getchar()) != EOF)
		putchar( c); // put the charater to the stdout
	return 0;
}

