/*******************************************************************************
*
* FILE:		Code_1_6_4.c
*
* DESC:		EECS 337 Homework Assignment 1
*
* AUTHOR:	caseid
*
* DATE:		August 28, 2012
*
* EDIT HISTORY:	
*
*******************************************************************************/
#include	<stdio.h>

//	enter the sample code from 1.6.4
