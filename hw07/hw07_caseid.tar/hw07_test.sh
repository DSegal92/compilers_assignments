#
#	hw07_test.sh
#
make clean
make
./calc < ../hw06/math1.calc
./calc < ../hw06/math2.calc
./calc < ../hw06/math3.calc
./calc < ../hw06/math4.calc
./calc < ../hw06/math5.calc
./calc < ../hw06/math6.calc
#./calc < ../hw06/math7.calc
#./calc < ../hw06/math8.calc
#./calc < ../hw06/math9.calc
