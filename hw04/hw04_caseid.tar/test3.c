if a3float < 1.1 then
if b3float <= 22.22 then else
if c3float = 333.333 then 
if d3float <> 4444.4444 then else
if e3float > 55555.55555 then 
if f3float >= 666666.666666 then else
