if a5octal < 01234567 then
if b5float <= 2. then else
if c5float = .3 then 
if d5float <> 4E1 then else
if e5float > 5.5e-5 then 
if f5hex >= 0xdeadbeef then else
