if a1 < 1 then
if b1 <= 2 then else
if c1 = 3 then 
if d1 <> 4 then else
if e1 > 5 then 
if f1 >= 6 then else
