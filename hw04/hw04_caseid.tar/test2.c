if a2integer < 1 then
if b2integer <= 22 then else
if c2integer = 333 then 
if d3integer <> 4444 then else
if e4integer > 55555 then 
if f2integer >= 666666 then else
