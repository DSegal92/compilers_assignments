if a4double < 1.1E1 then
if b4double <= 22.22E22 then else
if c4double = 333.333E+33 then 
if d4double <> 4444.4444E+44 then else
if e4double > 55555.55555E-55 then 
if f4double >= 666666.666666E-66 then else
