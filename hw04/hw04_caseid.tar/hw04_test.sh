#
#	hw04_test.sh
#
make clean
make
./ifrelop test1.c
./ifrelop test2.c
./ifrelop test3.c
./ifrelop test4.c
#./ifrelop test5.c
