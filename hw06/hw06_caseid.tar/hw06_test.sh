#
#	hw06_test.sh
#
make clean
make
./calc < math1.calc
./calc < math2.calc
./calc < math3.calc
./calc < math4.calc
./calc < math5.calc
./calc < math6.calc
#./calc < math7.calc
#./calc < math8.calc
#./calc < math9.calc
