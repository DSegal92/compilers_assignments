#
#	hw08_test.sh
#
make clean
make
./calc math10.calc
#./calc math11.calc
