#
#	hw09_test.sh
#
make clean
make
./calc math12.calc
./calc math13.calc
