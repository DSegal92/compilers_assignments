#
#	hw12_test.sh
#
make clean
make
./calc ../hw11/math17.calc
./calc ../hw11/math18.calc
./calc ../hw11/math19.calc
#./calc math20.calc
